import { Mic } from "lucide-react";
import { Button } from "@/components/ui/button";

interface EmptyStateProps {
  onStartRecording?: () => void;
}

export default function EmptyState({ onStartRecording }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] text-center px-4">
      <div className="relative mb-8">
        <div className="absolute inset-0 bg-primary/10 rounded-full blur-3xl" />
        <div className="relative h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
          <Mic className="h-12 w-12 text-primary" />
        </div>
      </div>
      
      <h2 className="font-display font-semibold text-2xl text-foreground mb-3">
        No notes yet
      </h2>
      <p className="text-muted-foreground max-w-md mb-8">
        Start recording your first voice note. Our AI will automatically transcribe,
        detect topics, and help you organize your thoughts.
      </p>
      
      <Button
        size="lg"
        onClick={onStartRecording}
        data-testid="button-start-first-recording"
        className="gap-2"
      >
        <Mic className="h-4 w-4" />
        Start Recording
      </Button>
    </div>
  );
}
