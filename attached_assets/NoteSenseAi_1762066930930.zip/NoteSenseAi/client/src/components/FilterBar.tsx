import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

interface FilterBarProps {
  categories: string[];
  selectedCategories: string[];
  onToggleCategory: (category: string) => void;
  onClearFilters: () => void;
}

export default function FilterBar({
  categories,
  selectedCategories,
  onToggleCategory,
  onClearFilters,
}: FilterBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-2 p-4 bg-card border border-card-border rounded-lg">
      <span className="text-sm text-muted-foreground font-medium">Filter:</span>
      
      {categories.map((category) => {
        const isSelected = selectedCategories.includes(category);
        return (
          <Badge
            key={category}
            variant={isSelected ? "default" : "secondary"}
            className="cursor-pointer hover-elevate"
            onClick={() => onToggleCategory(category)}
            data-testid={`filter-${category.toLowerCase()}`}
          >
            {category}
          </Badge>
        );
      })}
      
      {selectedCategories.length > 0 && (
        <Button
          size="sm"
          variant="ghost"
          onClick={onClearFilters}
          className="h-6 px-2 text-xs gap-1"
          data-testid="button-clear-filters"
        >
          Clear
          <X className="h-3 w-3" />
        </Button>
      )}
    </div>
  );
}
