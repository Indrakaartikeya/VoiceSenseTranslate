import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Clock, Languages, Sparkles } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface NoteCardProps {
  id: string;
  title: string;
  excerpt: string;
  topics: string[];
  timestamp: Date;
  wordCount: number;
  language: string;
  onSummarize?: () => void;
  onTranslate?: () => void;
  onClick?: () => void;
}

export default function NoteCard({
  title,
  excerpt,
  topics,
  timestamp,
  wordCount,
  language,
  onSummarize,
  onTranslate,
  onClick,
}: NoteCardProps) {
  return (
    <Card
      className="p-6 hover-elevate cursor-pointer transition-shadow"
      onClick={onClick}
      data-testid="card-note"
    >
      <div className="space-y-4">
        <div>
          <h3 className="font-display font-semibold text-lg text-foreground line-clamp-2 mb-2">
            {title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-3">
            {excerpt}
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          {topics.map((topic, index) => (
            <Badge
              key={index}
              variant="secondary"
              className="text-xs"
              data-testid={`badge-topic-${index}`}
            >
              {topic}
            </Badge>
          ))}
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t border-border">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1" data-testid="text-timestamp">
              <Clock className="h-3 w-3" />
              {formatDistanceToNow(timestamp, { addSuffix: true })}
            </span>
            <span className="flex items-center gap-1" data-testid="text-wordcount">
              <FileText className="h-3 w-3" />
              {wordCount} words
            </span>
            <span className="flex items-center gap-1" data-testid="text-language">
              <Languages className="h-3 w-3" />
              {language}
            </span>
          </div>
          
          <div className="flex gap-1">
            <Button
              size="icon"
              variant="ghost"
              onClick={(e) => {
                e.stopPropagation();
                onSummarize?.();
              }}
              data-testid="button-summarize"
              className="h-7 w-7"
            >
              <Sparkles className="h-3 w-3" />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={(e) => {
                e.stopPropagation();
                onTranslate?.();
              }}
              data-testid="button-translate"
              className="h-7 w-7"
            >
              <Languages className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
