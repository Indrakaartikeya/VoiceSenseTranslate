import { Mic, Square, Pause } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type RecordingState = "idle" | "recording" | "paused";

interface RecordingButtonProps {
  state: RecordingState;
  onRecord: () => void;
  onStop: () => void;
  onPause: () => void;
}

export default function RecordingButton({
  state,
  onRecord,
  onStop,
  onPause,
}: RecordingButtonProps) {
  const isRecording = state === "recording";
  const isPaused = state === "paused";

  return (
    <div className="fixed bottom-8 right-8 z-50 flex flex-col items-center gap-4">
      {(isRecording || isPaused) && (
        <div className="flex gap-2 bg-background/95 backdrop-blur-md border border-border rounded-full px-4 py-2 shadow-lg">
          <Button
            size="icon"
            variant="ghost"
            onClick={onPause}
            data-testid="button-pause-recording"
            className="h-9 w-9"
          >
            <Pause className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="destructive"
            onClick={onStop}
            data-testid="button-stop-recording"
            className="h-9 w-9"
          >
            <Square className="h-3 w-3 fill-current" />
          </Button>
        </div>
      )}
      
      <button
        onClick={onRecord}
        data-testid="button-start-recording"
        className={cn(
          "h-16 w-16 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 hover-elevate active-elevate-2",
          isRecording
            ? "bg-destructive text-destructive-foreground animate-pulse"
            : "bg-primary text-primary-foreground"
        )}
      >
        <Mic className="h-6 w-6" />
      </button>
    </div>
  );
}
