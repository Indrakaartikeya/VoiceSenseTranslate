import { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Mic, Square, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface RecordingModalProps {
  open: boolean;
  onClose: () => void;
  onRecordingComplete: (audioBlob: Blob) => void;
}

export default function RecordingModal({ open, onClose, onRecordingComplete }: RecordingModalProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (open && !isRecording) {
      startRecording();
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
        mediaRecorderRef.current.stop();
      }
    };
  }, [open]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(chunksRef.current, { type: "audio/webm" });
        onRecordingComplete(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);

      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      setError("Failed to access microphone. Please grant permission.");
      console.error("Recording error:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" data-testid="modal-recording">
        <DialogHeader>
          <DialogTitle className="font-display">Recording Voice Note</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {error ? (
            <div className="text-center space-y-4">
              <p className="text-sm text-destructive">{error}</p>
              <Button onClick={onClose} data-testid="button-close-error">
                Close
              </Button>
            </div>
          ) : (
            <>
              <div className="flex flex-col items-center gap-4">
                <div className={cn(
                  "h-24 w-24 rounded-full flex items-center justify-center transition-all",
                  isRecording ? "bg-destructive/10 animate-pulse" : "bg-muted"
                )}>
                  <Mic className={cn(
                    "h-12 w-12",
                    isRecording ? "text-destructive" : "text-muted-foreground"
                  )} />
                </div>
                
                <div className="text-center">
                  <div className="text-3xl font-display font-bold text-foreground" data-testid="text-recording-time">
                    {formatTime(recordingTime)}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {isRecording ? "Recording in progress..." : "Preparing..."}
                  </p>
                </div>
              </div>

              <div className="flex justify-center gap-2">
                <Button
                  variant="destructive"
                  onClick={stopRecording}
                  disabled={!isRecording}
                  data-testid="button-stop-recording-modal"
                  className="gap-2"
                >
                  <Square className="h-4 w-4 fill-current" />
                  Stop Recording
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
