import EmptyState from "../EmptyState";

export default function EmptyStateExample() {
  return (
    <div className="p-4">
      <EmptyState onStartRecording={() => console.log("Start recording")} />
    </div>
  );
}
