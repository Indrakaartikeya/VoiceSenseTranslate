import FilterBar from "../FilterBar";
import { useState } from "react";

export default function FilterBarExample() {
  const [selected, setSelected] = useState<string[]>(["Business"]);
  
  const categories = ["All", "Business", "Personal", "Ideas", "Meetings", "Travel"];

  return (
    <div className="p-4">
      <FilterBar
        categories={categories}
        selectedCategories={selected}
        onToggleCategory={(cat) => {
          setSelected((prev) =>
            prev.includes(cat)
              ? prev.filter((c) => c !== cat)
              : [...prev, cat]
          );
        }}
        onClearFilters={() => setSelected([])}
      />
    </div>
  );
}
