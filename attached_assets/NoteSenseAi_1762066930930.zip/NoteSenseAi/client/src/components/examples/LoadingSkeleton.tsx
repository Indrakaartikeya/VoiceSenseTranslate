import LoadingSkeleton from "../LoadingSkeleton";

export default function LoadingSkeletonExample() {
  return (
    <div className="p-4 max-w-md">
      <LoadingSkeleton />
    </div>
  );
}
