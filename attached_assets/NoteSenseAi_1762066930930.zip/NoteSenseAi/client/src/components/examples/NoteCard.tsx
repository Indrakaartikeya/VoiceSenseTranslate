import NoteCard from "../NoteCard";

export default function NoteCardExample() {
  return (
    <div className="p-4 max-w-md">
      <NoteCard
        id="1"
        title="Team Meeting Notes"
        excerpt="Discussed Q4 goals, marketing strategy, and upcoming product launches. Action items include finalizing the roadmap and scheduling follow-ups with stakeholders."
        topics={["Business", "Strategy", "Planning"]}
        timestamp={new Date(Date.now() - 3600000)}
        wordCount={247}
        language="EN"
        onSummarize={() => console.log("Summarize clicked")}
        onTranslate={() => console.log("Translate clicked")}
        onClick={() => console.log("Note clicked")}
      />
    </div>
  );
}
