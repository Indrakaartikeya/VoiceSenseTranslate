import RecordingButton from "../RecordingButton";
import { useState } from "react";

export default function RecordingButtonExample() {
  const [state, setState] = useState<"idle" | "recording" | "paused">("idle");

  return (
    <RecordingButton
      state={state}
      onRecord={() => {
        console.log("Recording started");
        setState("recording");
      }}
      onStop={() => {
        console.log("Recording stopped");
        setState("idle");
      }}
      onPause={() => {
        console.log("Recording paused");
        setState(state === "paused" ? "recording" : "paused");
      }}
    />
  );
}
