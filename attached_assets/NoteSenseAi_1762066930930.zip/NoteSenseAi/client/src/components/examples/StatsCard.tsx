import StatsCard from "../StatsCard";
import { FileText, Clock, Languages } from "lucide-react";

export default function StatsCardExample() {
  return (
    <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
      <StatsCard
        icon={FileText}
        label="Total Notes"
        value={42}
        color="primary"
      />
      <StatsCard
        icon={Clock}
        label="Hours Recorded"
        value="12.5"
        color="secondary"
      />
      <StatsCard
        icon={Languages}
        label="Languages"
        value={3}
        color="accent"
      />
    </div>
  );
}
