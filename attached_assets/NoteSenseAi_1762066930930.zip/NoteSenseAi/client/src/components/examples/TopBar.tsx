import TopBar from "../TopBar";

export default function TopBarExample() {
  return (
    <TopBar
      userName="Sarah Johnson"
      onSearch={(query) => console.log("Search:", query)}
      onLogout={() => console.log("Logout clicked")}
    />
  );
}
