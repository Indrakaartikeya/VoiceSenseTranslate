import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import TopBar from "@/components/TopBar";
import NoteCard from "@/components/NoteCard";
import EmptyState from "@/components/EmptyState";
import RecordingButton from "@/components/RecordingButton";
import RecordingModal from "@/components/RecordingModal";
import FilterBar from "@/components/FilterBar";
import StatsCard from "@/components/StatsCard";
import LoadingSkeleton from "@/components/LoadingSkeleton";
import { FileText, Clock, Languages } from "lucide-react";
import type { Note } from "@shared/schema";

export default function Dashboard() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [showRecordingModal, setShowRecordingModal] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch notes
  const { data: notes = [], isLoading: notesLoading } = useQuery<Note[]>({
    queryKey: ["/api/notes", searchQuery],
    enabled: isAuthenticated,
  });

  // Fetch stats
  const { data: stats } = useQuery<{ totalNotes: number; totalWords: number; languages: number }>({
    queryKey: ["/api/notes/stats"],
    enabled: isAuthenticated,
  });

  // Upload and transcribe audio
  const transcribeMutation = useMutation({
    mutationFn: async (audioBlob: Blob) => {
      const formData = new FormData();
      formData.append("audio", audioBlob, "recording.webm");
      
      const response = await fetch("/api/notes/transcribe", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to transcribe audio");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notes/stats"] });
      toast({
        title: "Success",
        description: "Your voice note has been transcribed!",
      });
      setShowRecordingModal(false);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to transcribe audio",
        variant: "destructive",
      });
      setShowRecordingModal(false);
    },
  });

  // Summarize note
  const summarizeMutation = useMutation({
    mutationFn: async (noteId: string) => {
      return apiRequest("POST", `/api/notes/${noteId}/summarize`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      toast({
        title: "Summary Generated",
        description: "AI summary has been added to your note",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to generate summary",
        variant: "destructive",
      });
    },
  });

  // Delete note
  const deleteMutation = useMutation({
    mutationFn: async (noteId: string) => {
      return apiRequest("DELETE", `/api/notes/${noteId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notes/stats"] });
      toast({
        title: "Note Deleted",
        description: "Your note has been removed",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete note",
        variant: "destructive",
      });
    },
  });

  const categories = ["All", "Business", "Personal", "Ideas", "Meetings", "Travel"];

  // Filter notes by selected categories
  const filteredNotes = notes.filter((note) => {
    const matchesCategory = selectedCategories.length === 0 ||
      note.topics.some((topic) => selectedCategories.includes(topic));
    
    return matchesCategory;
  });

  const hasNotes = notes.length > 0;
  
  const userName = user ? `${user.firstName || ""} ${user.lastName || ""}`.trim() || "User" : "User";

  if (authLoading || notesLoading) {
    return (
      <div className="min-h-screen bg-background">
        <TopBar userName={userName} onSearch={setSearchQuery} onLogout={() => window.location.href = "/api/logout"} />
        <main className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <LoadingSkeleton />
            <LoadingSkeleton />
            <LoadingSkeleton />
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <TopBar
        userName={userName}
        onSearch={setSearchQuery}
        onLogout={() => window.location.href = "/api/logout"}
      />

      <main className="container mx-auto px-4 py-8">
        {hasNotes ? (
          <div className="space-y-8">
            <div>
              <h2 className="font-display font-bold text-3xl text-foreground mb-2">
                Welcome back{user?.firstName ? `, ${user.firstName}` : ""}
              </h2>
              <p className="text-muted-foreground">
                Here's what you've captured recently
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <StatsCard
                icon={FileText}
                label="Total Notes"
                value={stats?.totalNotes || 0}
                color="primary"
              />
              <StatsCard
                icon={Clock}
                label="Total Words"
                value={stats?.totalWords || 0}
                color="secondary"
              />
              <StatsCard
                icon={Languages}
                label="Languages"
                value={stats?.languages || 0}
                color="accent"
              />
            </div>

            <FilterBar
              categories={categories}
              selectedCategories={selectedCategories}
              onToggleCategory={(cat) => {
                setSelectedCategories((prev) =>
                  prev.includes(cat)
                    ? prev.filter((c) => c !== cat)
                    : [...prev, cat]
                );
              }}
              onClearFilters={() => setSelectedCategories([])}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredNotes.length > 0 ? (
                filteredNotes.map((note) => (
                  <NoteCard
                    key={note.id}
                    id={note.id}
                    title={note.title}
                    excerpt={note.transcript.substring(0, 150) + (note.transcript.length > 150 ? "..." : "")}
                    topics={note.topics}
                    timestamp={new Date(note.createdAt)}
                    wordCount={note.wordCount}
                    language={note.language}
                    onSummarize={() => summarizeMutation.mutate(note.id)}
                    onTranslate={() => toast({ title: "Coming Soon", description: "Translation feature is being implemented" })}
                    onClick={() => toast({ title: "Note Details", description: "Detailed view coming soon" })}
                  />
                ))
              ) : (
                <div className="col-span-full">
                  <p className="text-center text-muted-foreground py-12">
                    No notes match your filters
                  </p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <EmptyState onStartRecording={() => setShowRecordingModal(true)} />
        )}
      </main>

      <RecordingButton
        state="idle"
        onRecord={() => setShowRecordingModal(true)}
        onStop={() => {}}
        onPause={() => {}}
      />

      <RecordingModal
        open={showRecordingModal}
        onClose={() => setShowRecordingModal(false)}
        onRecordingComplete={(blob) => transcribeMutation.mutate(blob)}
      />
    </div>
  );
}
