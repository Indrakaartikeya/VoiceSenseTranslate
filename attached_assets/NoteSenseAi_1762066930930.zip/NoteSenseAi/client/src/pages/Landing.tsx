import { Button } from "@/components/ui/button";
import { Mic, Sparkles, Languages, Brain } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-display font-bold text-sm">VN</span>
            </div>
            <h1 className="font-display font-bold text-xl text-foreground">VoiceNote</h1>
          </div>
          
          <Button asChild data-testid="button-login">
            <a href="/api/login">Sign In</a>
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="relative mb-12">
            <div className="absolute inset-0 bg-primary/10 rounded-full blur-3xl" />
            <div className="relative h-32 w-32 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
              <Mic className="h-16 w-16 text-primary" />
            </div>
          </div>

          <div className="space-y-4">
            <h1 className="font-display font-bold text-5xl text-foreground">
              Voice Notes, Powered by AI
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Transcribe your voice, detect topics automatically, and get AI-powered summaries.
              Your thoughts, organized effortlessly.
            </p>
          </div>

          <div className="flex gap-4 justify-center pt-4">
            <Button size="lg" asChild data-testid="button-get-started">
              <a href="/api/login" className="gap-2">
                <Mic className="h-4 w-4" />
                Get Started Free
              </a>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-16">
            <div className="space-y-3">
              <div className="h-12 w-12 mx-auto rounded-lg bg-primary/10 flex items-center justify-center">
                <Mic className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-display font-semibold text-lg">Voice to Text</h3>
              <p className="text-muted-foreground text-sm">
                Record your thoughts and get instant, accurate transcriptions powered by OpenAI Whisper
              </p>
            </div>

            <div className="space-y-3">
              <div className="h-12 w-12 mx-auto rounded-lg bg-chart-2/10 flex items-center justify-center">
                <Brain className="h-6 w-6 text-chart-2" />
              </div>
              <h3 className="font-display font-semibold text-lg">Smart Topics</h3>
              <p className="text-muted-foreground text-sm">
                AI automatically detects and categorizes your notes by topic for easy organization
              </p>
            </div>

            <div className="space-y-3">
              <div className="h-12 w-12 mx-auto rounded-lg bg-chart-3/10 flex items-center justify-center">
                <Languages className="h-6 w-6 text-chart-3" />
              </div>
              <h3 className="font-display font-semibold text-lg">Multi-Language</h3>
              <p className="text-muted-foreground text-sm">
                Translate your notes instantly to any language with AI-powered translation
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
