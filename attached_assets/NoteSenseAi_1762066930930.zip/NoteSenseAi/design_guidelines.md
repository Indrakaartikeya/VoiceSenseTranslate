# Design Guidelines: Voice-Controlled Notes Application

## Design Approach
**Reference-Based Design** drawing from Otter.ai's conversational recording interface and Notion's clean, organized workspace aesthetic. This combines Otter's real-time transcription feedback patterns with Notion's sophisticated content organization.

## Color System (User-Specified)
- **Primary**: #6366F1 (Indigo) - Main actions, links, active states
- **Secondary**: #8B5CF6 (Purple) - AI features, smart categorization badges
- **Background**: #F8FAFC (Light grey) - Main canvas, card backgrounds
- **Text**: #1E293B (Slate) - Body text, headings
- **Accent**: #10B981 (Emerald) - Success states, completed actions
- **Recording**: #EF4444 (Red) - Active recording indicator, live states

## Typography
**Font Families** (Google Fonts CDN):
- Primary: 'Inter' - UI elements, body text, labels
- Display: 'Poppins' - Headings, note titles, section headers

**Type Scale**:
- Display (Poppins): 48px/56px bold - Dashboard headers
- H1 (Poppins): 32px/40px semibold - Page titles
- H2 (Poppins): 24px/32px semibold - Section headers
- H3 (Poppins): 20px/28px medium - Card titles, note headers
- Body Large (Inter): 16px/24px regular - Primary content
- Body (Inter): 14px/20px regular - Standard text, transcriptions
- Small (Inter): 12px/16px regular - Metadata, timestamps

## Layout System
**Container Strategy**:
- Dashboard: Full-width with max-w-7xl center constraint
- Note Editor: max-w-4xl for optimal reading width
- Sidebar: Fixed 280px width on desktop, drawer on mobile

**Spacing Primitives** (Tailwind):
Primary units: 2, 4, 8, 12, 16, 20
- Component padding: p-4 to p-6
- Section spacing: py-12 to py-20
- Card gaps: gap-4 to gap-6
- Icon-text spacing: gap-2

## Core Components

### Navigation
**Top Bar** (Fixed, Otter.ai style):
- Logo (left) + Search bar (center) + User menu (right)
- Height: h-16, background blur effect (backdrop-blur-lg)
- Clean horizontal navigation with active state indicators

**Sidebar** (Notion-inspired):
- Collapsible category tree with nested organization
- Recent notes quick access (max 5 items)
- Category badges with note counts
- Smooth transitions on collapse/expand

### Recording Interface
**Floating Action Button** (Primary feature):
- Position: Fixed bottom-right, bottom-8 right-8
- Size: 64px diameter, rounded-full
- Recording state: Pulsing red background (#EF4444) with waveform animation
- Idle state: Indigo background (#6366F1) with microphone icon
- Background: Blurred backdrop (backdrop-blur-md bg-white/80)

**Recording Panel** (Expands from FAB):
- Real-time transcription display with typing indicator
- Waveform visualization (simple bars, minimal animation)
- Timer and pause/stop controls
- Language selector dropdown
- Auto-save indicator (emerald checkmark)

### Note Cards
**Layout** (Card-based grid):
- Grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Card design: Rounded-xl borders with subtle shadow (shadow-sm hover:shadow-md)
- Padding: p-6
- Elements per card:
  - Title (H3 Poppins, truncate after 2 lines)
  - Excerpt (Body, 3-line clamp with fade)
  - Topic badges (pill-shaped, secondary color)
  - Metadata row: timestamp + word count + language flag
  - Quick actions: summarize, translate, share icons

### Note Detail View
**Two-column layout**:
- Left (60%): Full transcription with timestamps
- Right (40%): AI insights sidebar
  - Summary card (auto-generated)
  - Topic tags (editable)
  - Translation selector
  - Related notes suggestions

### Forms & Inputs
**Input Fields**:
- Height: h-12
- Border: 2px solid, focus ring in primary color
- Rounded: rounded-lg
- Icon prefix spacing: pl-10 for icon inputs

**Buttons**:
- Primary: bg-indigo-600, rounded-lg, px-6 py-3
- Secondary: border-2 border-indigo-600, transparent bg
- Icon buttons: w-10 h-10, rounded-full

### AI Processing States
**Visual Feedback**:
- Processing: Shimmer effect on cards with gradient overlay
- Complete: Slide-in animation with emerald accent
- Error: Subtle red border pulse
- Loading skeleton: Rounded rectangles matching content structure

### Dashboard Layout
**Hero Section** (No image):
- Clean typography-first header with greeting
- Quick stats row: Total notes, hours recorded, languages used
- Primary CTA: "Start Recording" button (indigo, prominent)
- Height: Auto-height based on content

**Main Content**:
- Filter bar: Category pills + date range + search
- Notes grid with infinite scroll
- Empty state: Illustration placeholder with onboarding message

## Responsive Behavior
**Breakpoints**:
- Mobile (base): Single column, drawer navigation
- Tablet (md: 768px): Two-column grid, collapsible sidebar
- Desktop (lg: 1024px): Three-column grid, persistent sidebar
- Wide (xl: 1280px): Max container width, increased spacing

## Accessibility
- ARIA labels on all interactive elements
- Keyboard shortcuts: Space (record), Esc (stop), Cmd+S (save)
- Focus indicators: 3px outline in primary color
- Screen reader announcements for recording states
- Color contrast: WCAG AA minimum (4.5:1 for text)

## Icons
**Library**: Heroicons (via CDN)
- Microphone, document, tag, translate, sparkles (AI), clock

## Images
No hero images required. Focus on clean, content-first interface with illustrative empty states for onboarding.