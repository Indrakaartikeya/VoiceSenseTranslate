// Reference: blueprint:javascript_openai
import OpenAI from "openai";
import fs from "fs";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
function getOpenAIClient() {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY is not configured. Please add your OpenAI API key to continue.");
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

export async function transcribeAudio(audioFilePath: string): Promise<{ text: string }> {
  const openai = getOpenAIClient();
  const audioReadStream = fs.createReadStream(audioFilePath);

  const transcription = await openai.audio.transcriptions.create({
    file: audioReadStream,
    model: "whisper-1",
  });

  return {
    text: transcription.text,
  };
}

export async function detectTopics(text: string): Promise<string[]> {
  try {
    const openai = getOpenAIClient();
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content:
            "You are a topic detection expert. Analyze the text and identify 2-4 main topics or categories. Return only the topic names as a JSON array of strings. Topics should be single words or short phrases like 'Business', 'Travel', 'Ideas', 'Meeting', etc.",
        },
        {
          role: "user",
          content: text,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.topics || [];
  } catch (error) {
    console.error("Failed to detect topics:", error);
    return ["General"];
  }
}

export async function summarizeText(text: string): Promise<string> {
  try {
    const openai = getOpenAIClient();
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content:
            "You are a summarization expert. Create a concise summary of the text that captures the main points and key information in 2-3 sentences.",
        },
        {
          role: "user",
          content: text,
        },
      ],
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Failed to summarize text:", error);
    throw new Error("Failed to generate summary");
  }
}

export async function translateText(text: string, targetLanguage: string): Promise<string> {
  try {
    const openai = getOpenAIClient();
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a professional translator. Translate the following text to ${targetLanguage}. Maintain the original tone and meaning.`,
        },
        {
          role: "user",
          content: text,
        },
      ],
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Failed to translate text:", error);
    throw new Error("Failed to translate text");
  }
}
