// Reference: blueprint:javascript_log_in_with_replit
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertNoteSchema } from "@shared/schema";
import { transcribeAudio, detectTopics, summarizeText, translateText } from "./openai";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Note routes
  app.post("/api/notes/transcribe", isAuthenticated, upload.single("audio"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const audioFile = req.file;

      if (!audioFile) {
        return res.status(400).json({ message: "No audio file provided" });
      }

      // Transcribe audio
      const { text } = await transcribeAudio(audioFile.path);
      
      // Detect topics
      const topics = await detectTopics(text);
      
      // Calculate word count
      const wordCount = text.split(/\s+/).filter(word => word.length > 0).length;
      
      // Generate title from first sentence or first few words
      const firstSentence = text.split(/[.!?]/)[0].trim();
      const title = firstSentence.length > 50 
        ? firstSentence.substring(0, 47) + "..." 
        : firstSentence;

      // Create note
      const note = await storage.createNote({
        userId,
        title,
        transcript: text,
        topics,
        wordCount,
        language: "EN",
      });

      // Clean up uploaded file
      fs.unlinkSync(audioFile.path);

      res.json(note);
    } catch (error: any) {
      console.error("Error transcribing audio:", error);
      res.status(500).json({ message: error.message || "Failed to transcribe audio" });
    }
  });

  app.get("/api/notes", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const searchQuery = req.query.search as string | undefined;
      const notes = await storage.getUserNotes(userId, searchQuery);
      res.json(notes);
    } catch (error) {
      console.error("Error fetching notes:", error);
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  app.get("/api/notes/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getNoteStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get("/api/notes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const noteId = req.params.id;
      const note = await storage.getNote(noteId, userId);
      
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      res.json(note);
    } catch (error) {
      console.error("Error fetching note:", error);
      res.status(500).json({ message: "Failed to fetch note" });
    }
  });

  app.post("/api/notes/:id/summarize", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const noteId = req.params.id;
      
      const note = await storage.getNote(noteId, userId);
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }

      const summary = await summarizeText(note.transcript);
      const updated = await storage.updateNote(noteId, userId, { summary });
      
      res.json(updated);
    } catch (error: any) {
      console.error("Error summarizing note:", error);
      res.status(500).json({ message: error.message || "Failed to summarize note" });
    }
  });

  app.post("/api/notes/:id/translate", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const noteId = req.params.id;
      const { language } = req.body;

      if (!language) {
        return res.status(400).json({ message: "Target language is required" });
      }

      const note = await storage.getNote(noteId, userId);
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }

      const translatedText = await translateText(note.transcript, language);
      
      res.json({ translatedText, language });
    } catch (error: any) {
      console.error("Error translating note:", error);
      res.status(500).json({ message: error.message || "Failed to translate note" });
    }
  });

  app.delete("/api/notes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const noteId = req.params.id;
      
      const deleted = await storage.deleteNote(noteId, userId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      res.json({ message: "Note deleted successfully" });
    } catch (error) {
      console.error("Error deleting note:", error);
      res.status(500).json({ message: "Failed to delete note" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
